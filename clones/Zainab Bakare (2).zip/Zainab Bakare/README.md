# zainab bakare
## cil internship

• cloud engineering
• frontend developer
• data science
• product manager

individuals and interactions over processes and tools