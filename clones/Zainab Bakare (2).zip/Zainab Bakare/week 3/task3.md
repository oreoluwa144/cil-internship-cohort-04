business analysis
https://drive.google.com/file/d/1c9RFdPpzpPaDLXOZ-XR9xrpA55rJ2XJz/view?usp=drivesdk