Describe any layered process you are familiar with similar to the OSI model
Making diagnosis in a hospital: History taking, examination, investigation, management. These are some of the layers involved and it's kind of similar to the OSI model, albeit not tech inclined.
 
Garri processing. This is also oddly similar to the OSI model. It involves the passage of the cassava through several layers before it ends up as the garri.
Then, there is the TCP/IP model This model is doesn't conform to the OSI model since the TCP/IP model is a standard based on the OSI model whilst the OSI model is a functional guidelines .
 
Cisco 3 layered structure: the core, the distribution and the access point perfectly fits into the OSI model idea  since both are based on functions 
Access layer: comprises of the end users devices like PCs, phones,printers. Web browsers which uses the application layer protocol of the OSI model is found as an app in PCs.
Wired and wireless access points and hubs which are devices found in the physical layer of the OSI model are also found at the access layer of the Cisco layer
Inside the web browsers you will get the presentation layers which converts human language to machine language and compresses data and encryption of data is ensured when a ssl is used.
Session layers is the app APIs which manages the sessions and does authentication and authorization.
Distribution layer: ensures routing of boundaries, filtering of traffic and Qos(quality of service), segmentation.
Segmentation, flow control are the functions of the transport layer of the OSI and the routers which are also found at this layer is also found at the transport layer of the OSI. LAN addressing are done here which is the network layer of the OSI.
Core layer: ensures connectivity to the internet which falls under the network layer of the OSI
SS7-Signaling system 7: Explains what happens in telecommunication, i.e how voice signal is transmitted from one end to another, it explains this process in layers similar to the OSI model;
Physical layer: defines the physical and electrical characteristics of the link
Message transfer layer part 2: it provides link layer functionality to ensure messages are reliably exchanged, it functions includes, error checking, flow control, and sequence checking.
Mmessageposs5. Mmessage transfer layer part 3: this layer provides addressing, routing,and congestion control
Signaling connection control part: provides capability to address application within a signaling point.piont.
Transaction capabilities application part: defines messages and protocols used to communicate between applications such as services, calling card services in the nodes and switches,,meassagesn
Operation, maintenance, and administration part: this layer functions includes, validation of route table and diagnosis of links.