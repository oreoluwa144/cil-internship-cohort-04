What are the NS IP addresses for Google, Facebook and Tesla?

NS IP address for 
Google is 216.58.223.238
Facebook is 102.132.101.35
Tesla is 23.9.66.10

“Breakdown the following RFC 1918 IPv4 address range into exactly 4 subnetwork with no address left over.” 
10.10.10.0 
192.168.0.0 
172.168.1.0


IP address range 10.10.10.1 to 10.10.10.6 network ID 10.10.10.0
Broadcast ID 10.10.10.7
Subnet mask 255.255.255.248


IP address range 192.168.0.1 to 192.168.0.6 network ID 192.168.0.0 Broadcast ID 192.168.0.7
Subnet mask 255.255.255.248


IP address range 172.168.1.1 to 172.168.1.6 network ID 172.168.1.0 Broadcast ID 172.168.1.7
Subnet mask 255.255.255.248